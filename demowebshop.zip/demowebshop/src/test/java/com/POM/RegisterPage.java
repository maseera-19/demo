package com.POM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage {
	
	@FindBy(linkText="Register")
	private WebElement registerButton;
	
	@FindBy(id="gender-male")
	private WebElement maleButton;
	
	@FindBy(id="FirstName")
	private WebElement fname;
	
	@FindBy(id="LastName")
	private WebElement lname;
	
	@FindBy(id="Email")
	private WebElement email;
	
	@FindBy(id="Password")
	private WebElement passwd;
	
	@FindBy(id="ConfirmPassword")
	private WebElement cpasswd;
	
	@FindBy(id="register-button")
	private WebElement register;
	
	@FindBy(linkText="Log out")
	private WebElement logout;
	
	
	
	public void registerButton() {
		registerButton.click();
	}
	
	public void Clickmale() {
		maleButton.click();
	}
	
	public void fname(String s) {
		fname.sendKeys(s);
	}
	
	public void lname(String s) {
		lname.sendKeys(s);
	}
	
	public void enterEmail(String em) {
		email.sendKeys(em);
	}
	
	public void enterPassword(String pass) {
		passwd.sendKeys(pass);
	}
	
	public void ConfirmPassword(String cpass) {
		cpasswd.sendKeys(cpass);
	}
	
	public void regButton() {
		register.click();
	}
	
	public void logout() {
		logout.click();
	}
	

}
