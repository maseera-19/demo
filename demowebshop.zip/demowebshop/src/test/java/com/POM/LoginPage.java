package com.POM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage{
	
	@FindBy(partialLinkText = "Log in")
	private WebElement LogInButton;
	
	@FindBy(id = "Email")
	private WebElement email;
	
	@FindBy(id="Password")	
	private WebElement password;
	
	@FindBy(xpath = "//input[contains(@class,'login-button')]")
	private WebElement login;
	
	@FindBy(linkText="Log out")
	private WebElement logout;
	
	
	public void loginButton() {
		LogInButton.click();
	}
	public void enterEmail(String s) {
		email.sendKeys(s);
	}
	
	public void enterPassword(String s) {
		password.sendKeys(s);
	}
	
	public void clickLogin() {
		login.click();
	}
	
	public void logout() {
		logout.click();
	}
	

}
