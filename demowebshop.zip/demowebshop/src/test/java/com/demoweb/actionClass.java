package com.demoweb;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class actionClass {
	static WebDriver driver;
	@Test
	public void alert() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "src/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		WebElement element= driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));

		Actions act=new Actions(driver);

		act.doubleClick(element).perform();
		//driver.findElement(By.xpath("(//a[contains(text(),'Desktops')])[1]")).click();
		Alert a=driver.switchTo().alert();
		System.out.println(a.getText());
		a.accept();
	}
	@AfterAll
	public static void close() {
		driver.quit();
	}

}
