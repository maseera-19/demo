package com.demoweb;

import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class Main {
	static WebDriver driver;
	@BeforeAll
    public static void setUp() {
        System.setProperty("webdriver.chrome.driver", "src/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://demowebshop.tricentis.com");
        driver.manage().window().maximize();
    }

    @Test
    @Order(1)
    public void registerTest() throws InterruptedException {
        driver.findElement(By.linkText("Register")).click();
        driver.findElement(By.id("gender-male")).click();
        driver.findElement(By.id("FirstName")).sendKeys("Aravindhraj");
        driver.findElement(By.id("LastName")).sendKeys("V");
        driver.findElement(By.id("Email")).sendKeys("aravindh16@gmail.com");
        driver.findElement(By.id("Password")).sendKeys("M@rch1996");
        driver.findElement(By.id("ConfirmPassword")).sendKeys("M@rch1996");
        driver.findElement(By.id("register-button")).click();
        Thread.sleep(4000);
        String actual = driver.findElement(By.xpath("//div[contains(text(),'Your registration completed')]")).getText();
        String expected = "Your registration completed";
        Assertions.assertEquals(expected,actual.trim());
        driver.findElement(By.xpath("//input[contains(@class,'register-continue-button')]")).click();
    }

    @Test
    @Order(2)
    public void searchBook(){
        driver.findElement(By.partialLinkText("Books")).click();
        driver.findElement(By.xpath("(//h2[contains(@class,'product-title')]/a)[1]")).click();
        String actual =  driver.findElement(By.xpath("//div[contains(@class,'product-price')]/label[contains(.,'Price')]")).getText();
        String expect = "Price:";
        Assertions.assertEquals(actual.trim(),expect);
        driver.findElement(By.xpath("//input[contains(@id,'add-to-cart-button')]")).click();
    }

    @Test
    @Order(3)
    public void viewCart(){
        driver.findElement(By.linkText("Shopping cart")).click();
        String actual = driver.findElement(By.xpath("//div[@class='page-title']/h1")).getText();
        String expect = "Shopping cart";
        Assertions.assertEquals(actual.trim(),expect);
    }
    @Test
    @Order(4)
    public void checkOut() throws InterruptedException {
        driver.findElement(By.id("checkout")).click();
        Select countrydropdown = new Select(driver.findElement(By.id("CountryId")));
        countrydropdown.selectByVisibleText("India");
        Select statedropdown= new Select(driver.findElement(By.id("StateProvinceId")));
        statedropdown.selectByVisibleText("Other (Non US)");
        driver.findElement(By.id("termsofservice")).click();
        driver.findElement(By.id("checkout")).click();
        Thread.sleep(5000);
    }
    @Test
    @Order(5)
    public void billingAddress() {
        driver.findElement(By.id("BillingNewAddress_FirstName")).sendKeys("Aravindhraj");
        driver.findElement(By.id("BillingNewAddress_LastName")).sendKeys("V");
        String email =  driver.findElement(By.xpath("(//a[contains(@class,'account')])[1]")).getText();
        driver.findElement(By.id("BillingNewAddress_Email")).sendKeys(email);
        driver.findElement(By.id("BillingNewAddress_Company")).sendKeys("xyz");
        Select country = new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
        country.selectByVisibleText("India");
        Select state = new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
        state.selectByVisibleText("Other (Non US)");
        driver.findElement(By.id("BillingNewAddress_City")).sendKeys("Chennai");
        driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys("xyz");
        driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys("8463890");
        driver.findElement(By.id("BillingNewAddress.PhoneNumber")).sendKeys("90265281936");
        driver.findElement(By.xpath("//div[@id='billing-buttons-container']/input[@title='Continue']")).click();
    }
    @AfterAll
    public static void closedriver(){
        driver.close();
    }

}
