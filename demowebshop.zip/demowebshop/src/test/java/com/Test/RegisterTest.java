package com.Test;
import com.POM.*;
import com.Utils.DriverUtils;
import com.Utils.ExcelData;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class RegisterTest {
	RegisterPage rp;	
	String firstName = "";
	String lastname = "";
	String email = "";
	String password = "";
	String cpassword = "";
	
	RegisterTest(){
		rp = new RegisterPage();
		firstName = ExcelData.getdata("src/input.xlsx", "register", 0, 0);
		lastname = ExcelData.getdata("src/input.xlsx", "register", 1, 0);
		email = ExcelData.getdata("src/input.xlsx", "register",2, 0);
		password = ExcelData.getdata("src/input.xlsx", "register", 3, 0);
		cpassword = ExcelData.getdata("src/input.xlsx", "register", 3, 0);
	}
	
	
	@Test
	public void Openregister() {
		rp.registerButton();
	}
	
	@Test(dependsOnMethods="Openregister", priority=1)
	public void happyflowRegister() {
		rp.Clickmale();
		rp.fname(firstName);
		rp.lname(lastname);
		rp.enterEmail(email);
		rp.enterPassword(password);
		rp.ConfirmPassword(cpassword);
		rp.regButton();
		String actual = DriverUtils.getDriver().findElement(By.xpath("//div[contains(text(),'Your registration completed')]")).getText();
        String expected = "Your registration completed";
        Assertions.assertEquals(expected,actual.trim());
        rp.logout();
	}
	
	@Test(priority=2)
	public void NullFirstname() {
		rp.registerButton();
		rp.Clickmale();
		rp.lname(lastname);
		rp.enterEmail(email);
		rp.enterPassword(password);
		rp.ConfirmPassword(cpassword);
		rp.regButton();
		String error = DriverUtils.getDriver().findElement(By.xpath("//span[contains(@class,'field-validation-error')]")).getText();
		Assert.assertEquals("First name is required.", error);
		
	}
	@Test(priority=3)
	public void NullLastName() {
		rp.registerButton();
		rp.Clickmale();
		rp.fname(firstName);
		rp.enterEmail(email);
		rp.enterPassword(password);
		rp.ConfirmPassword(cpassword);
		rp.regButton();
		String error = DriverUtils.getDriver().findElement(By.xpath("//span[contains(@class,'field-validation-error')]")).getText();
		Assert.assertEquals("Last name is required.", error);
		
	}
	
	@AfterTest
	public void close() {
		DriverUtils.getDriver().close();
	}

}
