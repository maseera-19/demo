package com.Test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import com.POM.LoginPage;
import com.Utils.DriverUtils;
import com.Utils.ExcelData;

public class SearchFlow {
		
		LoginPage lp = new LoginPage();
		String email = ExcelData.getdata("src/input.xlsx", "login", 0, 0);
		String password = ExcelData.getdata("src/input.xlsx", "login", 0, 1);
		@Test(priority=1)
		public void LoginHappyFlow() throws IOException {
			lp.loginButton();
			lp.enterEmail(email);
			lp.enterPassword(password);
			lp.clickLogin();
		}
	 	@Test(priority=2)
	    public void searchBook(){
	        DriverUtils.getDriver().findElement(By.partialLinkText("Books")).click();
	        DriverUtils.getDriver().findElement(By.xpath("(//h2[contains(@class,'product-title')]/a)[1]")).click();
	        String actual =  DriverUtils.getDriver().findElement(By.xpath("//div[contains(@class,'product-price')]/label[contains(.,'Price')]")).getText();
	        String expect = "Price:";
	        Assert.assertEquals(actual.trim(),expect);
	        DriverUtils.getDriver().findElement(By.xpath("//input[contains(@id,'add-to-cart-button')]")).click();
	    }

	    @Test(priority=3)
	    public void viewCart(){
	        DriverUtils.getDriver().findElement(By.linkText("Shopping cart")).click();
	        String actual = DriverUtils.getDriver().findElement(By.xpath("//div[@class='page-title']/h1")).getText();
	        String expect = "Shopping cart";
	        Assert.assertEquals(actual.trim(),expect);
	    }
	    @Test(priority=4)
	    public void checkOut() throws InterruptedException {
	        DriverUtils.getDriver().findElement(By.id("checkout")).click();
	        Select countrydropdown = new Select(DriverUtils.getDriver().findElement(By.id("CountryId")));
	        countrydropdown.selectByVisibleText("India");
	        Select statedropdown= new Select(DriverUtils.getDriver().findElement(By.id("StateProvinceId")));
	        statedropdown.selectByVisibleText("Other (Non US)");
	        DriverUtils.getDriver().findElement(By.id("termsofservice")).click();
	        DriverUtils.getDriver().findElement(By.id("checkout")).click();
	        Thread.sleep(5000);
	    }
	    @Test(priority=5)
	    public void billingAddress() {
	    	//DriverUtils.getDriver().findElement(By.id("BillingNewAddress_FirstName")).sendKeys("Aravindhraj");
	        //DriverUtils.getDriver().findElement(By.id("BillingNewAddress_LastName")).sendKeys("V");
	        //String email =  DriverUtils.getDriver().findElement(By.xpath("(//a[contains(@class,'account')])[1]")).getText();
	        //DriverUtils.getDriver().findElement(By.id("BillingNewAddress_Email")).sendKeys(email);
	       // DriverUtils.getDriver().findElement(By.id("BillingNewAddress_Company")).sendKeys("xyz");
	        Select country = new Select(DriverUtils.getDriver().findElement(By.id("BillingNewAddress_CountryId")));
	        country.selectByVisibleText("India");
	        Select state = new Select(DriverUtils.getDriver().findElement(By.id("BillingNewAddress_StateProvinceId")));
	        state.selectByVisibleText("Other (Non US)");
	        DriverUtils.getDriver().findElement(By.id("BillingNewAddress_City")).sendKeys("Chennai");
	        DriverUtils.getDriver().findElement(By.id("BillingNewAddress_Address1")).sendKeys("xyz");
	       // DriverUtils.getDriver().findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys("8463890");
	        //DriverUtils.getDriver().findElement(By.id("BillingNewAddress.PhoneNumber")).sendKeys("90265281936");
	        //DriverUtils.getDriver().findElement(By.xpath("//div[@id='billing-buttons-container']/input[@title='Continue']")).click();
	    }
	    @AfterTest
	    public static void closedriver(){
	        DriverUtils.getDriver().close();
	    }

}
