package com.Test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import com.POM.*;
import com.Utils.DriverUtils;
import com.Utils.ExcelData;
import java.io.IOException;

public class LoginTest {
		LoginPage lp = new LoginPage();
		String email = ExcelData.getdata("src/input.xlsx", "login", 0, 0);
		String password = ExcelData.getdata("src/input.xlsx", "login", 0, 1);
		@Test(priority=1)
		public void LoginHappyFlow() throws IOException {
			lp.loginButton();
			lp.enterEmail(email);
			lp.enterPassword(password);
			lp.clickLogin();
			lp.logout();
		}
		@Test(priority=2)
		public void wrongEmail() {
			lp.loginButton();
			lp.enterEmail(ExcelData.getdata("src/input.xlsx", "login", 1, 0));
			lp.enterPassword(password);
			lp.clickLogin();
			String error = DriverUtils.getDriver().findElement(By.xpath("(//div[contains(@class,'validation-summary-errors')]//li)[1]")).getText();
			Assert.assertEquals("No customer account found", error);
		}
		
		@Test(priority=3)
		public void wrongPassword() {
			lp.loginButton();
			lp.enterEmail(email);
			lp.enterPassword(password+"67");
			lp.clickLogin();
			String error = DriverUtils.getDriver().findElement(By.xpath("(//div[contains(@class,'validation-summary-errors')]//li)[1]")).getText();
			Assert.assertEquals("The credentials provided are incorrect", error);
		}
		
		@AfterTest
		public void close() {
			DriverUtils.closeDriver();
		}
		
}